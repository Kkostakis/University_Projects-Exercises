#!/bin/bash
# 3rd Exercise of Project

file=$1 # file argument
char=$2 # string argument

  echo "User please enter your choice:"
  read choice

  while [ $choice -lt 1 ] || [ $choice -gt 3 ] ;
  do
    echo "User please enter your choice(1-3):"
    read choice
  done

  if [ $choice -eq 1 ]
  then
      echo "The lines of the file $file which start from string $char are:"
      grep -n ^$char. $file # prints the files that start from the string
      echo ' '

      echo "The number of lines of the file $file which start from string $char is:"
      grep -n ^$char. $file | wc -l
  fi

  if [ $choice -eq 2 ]
  then
      echo "The lines of the file $file which contain the string $char are:"
      grep -n -F $char $file # prints the files that contain the string
      echo ' '

      echo "The number of lines of the file $file which contain the string $char is:"
      grep -n -Fc $char $file
  fi

  if [ $choice -eq 3 ]
  then
      echo "The lines of the file $file which end with the string $char are:"
      grep -n $char$ $file # prints the files that end with the string
      echo ' '

      echo "The number of lines of the file $file which end with string $char is:"
      grep -n $char$ $file | wc -l
  fi