#!/bin/bash
# 4th Exercise of Project

  num=$1

  while ! [ $num ] || ! [ $num 2>/dev/null ] ;
  do
    echo "User enter the number again:"
    read num
  done

  if [ $num -le 0 ] || [ $num -gt 14 ]
  then
      echo "The number you gave is out of desirable bounds and it cause an error"
      exit
  elif [ $num -gt 0 ] && [ $num -le 14 ]
  then

     if ! [[ $(find -type f -newermt "$num:00"  \! -newermt "$num:59") ]]
     then
         echo "This directory doesn't have files which were created at the desirable time and so exit from script"
         exit
     elif [[ $(find -type f -newermt "$num:00"  \! -newermt "$num:59") ]]
     then
           echo "The files in the current directory which were created between $num:00 and $num:59 are:"
           find -type f -newermt "$num:00" \! -newermt "$num:59"
           echo ' '

           echo "The contents of timefile are:"
           cat timefile
           echo ' '

           find -type f -newermt "$num:00"  \! -newermt "$num:59" > timefile
           echo "The contents of timefile (now) are:"
           cat timefile
     fi
  fi


