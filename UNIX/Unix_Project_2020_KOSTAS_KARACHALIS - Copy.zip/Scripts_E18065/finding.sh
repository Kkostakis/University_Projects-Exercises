#!/bin/bash
# 2nd Exercise of Project

num1=$1 # first argument
num2=$2 # second argument

n2=0 # count used to ensure that the function <<user can run this process(script) for as many times as he/she wants>> will work properly
tcount=0 # total count of files that were found
count1=0 # count of files that were found and then were stored at the first list
count2=0 # count of files which were modified at the last x days that were found and then were stored at the second list
count3=0 # count of files which were accessed at the last x days that were found and then were stored at the third list
count41=0 # count of files with .pipe extension that were found and then were stored at the fourth list
count42=0 # count of files with .socket extension that were found and then were stored at the fourth list
count5=0 # count of empty files that were found in the were found and then were stored at the fifth list

while ! [ $num1 ] || ! [ $num1 -eq $num1 2>/dev/null ] || [ $num1 -lt 0 ] || [ $num1 -gt 777 ] ; # check with do...while in order to ensure that the first number is integer
do                                                                                               # and between[0...777] because the file permissions have as max 7(e.g r=4,w=2,x=1 total = 7) with
  echo -n "User enter the first integer again:"                                                  # and 777 because the files rights concern only the user(u), the group(g) and the others(o)
  read num1
done

while ! [ $num2 ] || ! [ $num2 -eq $num2 2>/dev/null ] || [ $num2 -lt 0 ] ; # check with do..while to ensure that the second number is integer and non-negative(greater or equal to 0)
do                                                                          # on the grounds that a day cannot be a negative number(e.g -4 days)
  echo -n "User enter the second integer again:"
  read num2
done


echo "User enter how many times you wish to run the script:"
read preference

while [ $preference -lt 0 ] ; # check with do...while to ensure that the user will give a non-negative input for the number of times he/she wants the process to run
do
  echo "User enter again how many times you wish to run the script:"
  read preference
done

echo "User give me the name of the directory you wish to modify/run:"
read dirname

while [ $n2 != $preference ] ; # check with do...while to ensure that the process mentioned earlier will run properly
do
    echo "User enter your choice:"
    read choice

    while [ $choice -lt 1 ] || [ $choice -gt 5 ] ; # I used if..elif with choices because the user might not want to view all the lists but one of them at a time
    do                                             #  check with do...while that the choice will be [1..5] as the lists are bounded to [1..5]
      echo "User please enter your choice(1-5) again:"
      read choice
    done

    if [ $choice -eq 1 ]
    then
        echo "The number of files in the given directory with permission $num1 is:"
        find $dirname -type f -perm $num1 | wc -l # with find the script finds according to the name of the directory and the first num(permission number) the files with the permission number inside the directory and with wc -l the script finds each file as a line and so it counts each line inside the file and so we have the count of files with that permission and with -perm we have the the perm number as 8-bit
        count1=$(find $dirname -type f -perm $num1 | wc -l)
        echo ' '

        echo "The files in the given directory with permission $num1 are:"
        find $dirname -type f -perm $num1
        echo ' '

    elif [ $choice -eq 2 ]
    then
        echo "The number of files in the given directory which were modified in the last $num2 days is:"
        find $dirname -type f -mtime $num2 | wc -l # it is almost the same as above but with the small difference that it finds files in the directory with modification time(-mtime)
        count2=$(find $dirname -type f -mtime $num2 | wc -l)
        echo ' '

        echo "The files in the given directory which were modified in the last $num2 days are:"
        find $dirname -type f -mtime $num2
        echo ' '

     elif [ $choice -eq 3 ]
     then
         echo "The number of files in the given directory which were accessed in the last $num2 days is:"
         find $dirname -type f -atime $num2 | wc -l # it is almost the same as above but with the small difference that it finds files in the directory with access time(-atime)
         count3=$(find $dirname -type f -atime $num2 | wc -l)
         echo ' '

         echo "The files in the given directory which were accessed in the last $num2 days are:"
         find $dirname -type f -atime $num2
         echo ' '

     elif [ $choice -eq 4 ]
     then
         echo "User please choose whether you want to find pipe or socket files in the given directory:"
         read ch

         if [ "$ch" == "pipe" ]
         then
             echo "The number of pipe files in the given directory is:"
             find $dirname -type f -name "*.pipe" | wc -l
             count41=$(find $dirname -type f -name "*.pipe" | wc -l)
             echo ' '

             echo "The pipe files in the given directory are:"
             find $dirname -type f -name "*.pipe"
             echo ' '

         elif [ "$ch" == "socket" ]
         then
             echo "The number of socket files in the given directory is:"
             find $dirname -type f -name "*.socket" | wc -l
             count42=$(find $dirname -type f -name "*.socket" | wc -l)
             echo ' '

             echo "The socket files in the given directory are:"
             find $dirname -type f -name "*.socket"
             echo ' '
          fi

      elif [ $choice -eq 5 ]
      then
          echo "The number of empty files in the given directory is:"
          find $dirname -maxdepth 1 -type f -empty | wc -l
          count5=$(find $dirname -maxdepth 1 -type f -empty | wc -l)
          echo ' '

          echo "The empty files in the given directory are:"
          find $dirname -maxdepth 1 -type f -empty
          echo ' '
      fi

      n2=$(($n2 + 1))

done

      tcount=$(($count1 + $count2 + $count3 + $count41 + $count42 + $count5))
      echo "The total number of files that were found is:"$tcount
      echo ' '

      echo "                   <<History>>"
      echo "The number of files found in the 1st function is:"$count1
      echo "The number of files found in the 2nd function is:"$count2

       echo "The number of files found in the 3rd function is:"$count3

      if [ -z "$ch" ]
      then
          echo "The user didn't want to view either pipe or socket files"

      elif [ "$ch" == "pipe" ]
      then
          echo "The number of pipe files found in the 4th function is:"$count41

      elif [ "$ch" == "socket" ]
      then
          echo "The number of socket files found in the 4th function is:"$count42
      fi

      echo "The number of files found in the 5th function is:"$count5
