#!/bin/bash
# 1st Exercise of Project

echo -n "User enter the number of times you would like the process to run:"
read choice

while [ $choice -lt 0 ] ;  # check with loop do..while to ensure that the user won't enter a negative input for the times needed to run the process
do
  echo -n "User enter once more the number of times you would like the process to run:"
  read choice
done

count=0 # sum for number of equations which have two real roots
n1=0 # count which is used to utilise the function <<the user can run this process as many times as he/she wants>>

while [ $n1 != $choice ] ;
do

  echo -n "Enter the first integer:"
  read x

  while ! [ $x ] || ! [ $x -eq $x 2>/dev/null ] ; # check with do..while to ensure that the user will give as input only integers(positive, negative, zero) and not decimals
  do
    echo -n "Enter again the first integer:"
    read x
  done

  echo -n "Enter the second integer:"
  read y

  while ! [ $y ] || ! [ $y -eq $y 2>/dev/null ] ; # same for second number
  do
    echo -n "Enter again the second integer:"
    read y
  done

  echo -n "Enter the third integer:"
  read z

  while ! [ $z ] || ! [ $z -eq $z 2>/dev/null ] ; # same for third number
  do
    echo -n "Enter again the third integer:"
    read z
  done

echo ' '

equation() # function which calculates the discriminant of the equation 2ax+by+c=0
{

 a=$1
 b=$2
 c=$3
 D=$((b**2 - 4*a*c))

 echo  "The discriminant of the second_class equation is:" $D
 return $D
}

 equation x y z # the function equation() which takes as arguments the numbers x, y, z
 discriminant=$D
 num=0

echo ' '

 if [ $discriminant -gt $num ] # prints message according to the sign of the discriminant
 then
     echo  "This equation has two real roots"
     count=$(($count + 1))
 elif [ $discriminant -eq $num ]
 then
     echo  "This equation has a double root"
 elif [ $discriminant -lt $num ]
 then
     echo  "This equation has two complex roots"
 fi

n1=$(($n1 + 1))

done

echo ' '
echo "The number of equations which have two real roots is:"$count # prints the total sum of the equations with two real roots
