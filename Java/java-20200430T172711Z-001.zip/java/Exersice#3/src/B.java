interface B {

	String B = "BBB";
	
	String methodB();
}
