
public class D extends C
{
	String D = "DDD";
	
	public String methodA()
	{
		return D+methodB();
	}

}
