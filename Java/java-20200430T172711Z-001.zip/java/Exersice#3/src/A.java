
interface A {

	String A = "AAA";
	
	String methodA();
}
