import java.io.BufferedReader;                                       
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Scanner; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
 

@SuppressWarnings("serial")

public class Client extends JFrame implements ActionListener {
	
	static String maincourse,dessert,drink;
	static int total_seats,reserved_seats;
	static String password,kind_seat;
	static int rows,columns,rowsb;
	static String ticketcode;
	static Ticket ticketclient;
	

	   JPanel panel;
	   JLabel user_label, password_label, message;
	   JTextField userName_text;
	   JPasswordField password_text;
	   JButton submit, cancel;

	   Client() {

	      // User's name Label
		   
	      user_label = new JLabel();
	      user_label.setText("Username:");
	      userName_text = new JTextField();

	      // Password Label

	      password_label = new JLabel();
	      password_label.setText("Password:");
	      password_text = new JPasswordField();

	      // Submit

	      submit = new JButton("Submit");

	      panel = new JPanel(new GridLayout(3, 1));
	      panel.add(user_label);
	      panel.add(userName_text);
	      panel.add(password_label);
	      panel.add(password_text);

	      message = new JLabel();
	      panel.add(message);
	      panel.add(submit);

	      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	      // Adding the listeners to components..
	      
	      submit.addActionListener(this);
	      add(panel, BorderLayout.CENTER);
	      setTitle("Please Login Here!!!");
	      setSize(400,100);
	      setVisible(true);
	   }
	
	@SuppressWarnings({ "static-access", "unused" })
	
	public static void main(String[] args) throws IOException {
		    
			ArrayList<Airplane> arrayplane = new ArrayList<Airplane>();
			ArrayList<Menu> arraymenu = new ArrayList<Menu>();
			ArrayList<Flight> arrayflight = new ArrayList<Flight>();
			ArrayList<Ticket> arrayticket = new ArrayList<Ticket>();
			
			Scanner input = new Scanner(System.in);
			BufferedReader enter =  new BufferedReader(new InputStreamReader(System.in)); 
		
			int choice;
			String type_ticket;
			int price;
			
			new Client();
			
		
				
				
		{
				
			do // the initial menu of choices 
			{
			
			   do
			   {
			      System.out.println("\n\t<<Menu of choices>>");
			      System.out.println("[0] Exit");
			      System.out.println("[1] Insert Airplane");
			      System.out.println("[2] Insert Menu");
			      System.out.println("[3] Insert Flight");
			      System.out.println("[4] Cancel Flight");
			      System.out.println("[5] Book Ticket");
			      System.out.println("[6] Cancel Ticket");
			      System.out.println("[7] Order Menu Items(Only for business seats)");
			      System.out.println("[8] Seats Capacity for a certain Flight\n");
			      System.out.print("User please insert your choice:");
			      choice = input.nextInt();
			      
			   }while(choice < 0 || choice > 8); // do...while to ensure that the user will enter choices from 0 to 8
			      
			   
			   if(choice == 0) // Exit
			   {
				   System.out.println("Thank you for choosing our airlines!!!");
				   System.exit(0);
			   }
			   
			   else if(choice == 1) // Insert Airplane
			   {

				   boolean hold = false;
				   int i;
				   
				   System.out.print("User enter the code of the airplane:");
				   password = enter.readLine();
					   
				   System.out.print("User give a description of the airplane:");
				   String description = enter.readLine();
					   
			       do
				   {
						System.out.print("User enter the number of rows:");
						rows = input.nextInt();
			       }while(rows <= 0);
					   
				   do
				   {
						System.out.print("User enter the number of columns:");
						columns = input.nextInt();
				   }while(columns <= 0);
					   
				   do
				   {
						System.out.print("Enter the rows for the business class passengers:");
						rowsb = input.nextInt();   
				   }while(rowsb <= 0);
				   
				   Airplane planeclient = new Airplane(password,rows,columns,description,rowsb);
					   
	               for(i=0;i<arrayplane.size();i++)
	               {
	            	   planeclient = arrayplane.get(i);
	            	   
	            	   if(password.equals(planeclient.getCODE()))
	            	   {
	            		   hold = true;
	            		   System.out.println("\nThe code exists in the database!!\n");
	            		   break;
	            	   }
	               }

	               if(!hold)
	               {
	            	   System.out.println("\nThe password does not exist in the database.It will be added now!\n");
	            	   arrayplane.add(planeclient);
	               }
				   
	               else
				   {
					  
					  for(i=0;i<arrayplane.size();i++)
					   {
						   
						   System.out.println("Password:" + arrayplane.get(i).getCODE());
						   System.out.println("Description:" + arrayplane.get(i).getDESCRIPTION());
						   System.out.println("Number of rows:" + arrayplane.get(i).getROWS());
						   System.out.println("Number of columns:" + arrayplane.get(i).getCOLUMNS());
						   System.out.println("Rows(for business class passengers):" + arrayplane.get(i).getBUSINESS());
						   System.out.print("\n");
						  
					   }
				  }
				   	   
				  
			   }
			   
			   else if(choice == 2) // Insert Menu
			   {
				   boolean found = false;
				   int x;
				   
				   String menucode = password;
					   
				   System.out.print("User insert the maindish:");
				   maincourse = enter.readLine();
					   
			       System.out.print("User insert the dessert:");
				   dessert = enter.readLine();
					   
				   System.out.print("User insert the drink:");
				   drink = enter.readLine();
					   
				   Menu menuclient = new Menu(menucode,maincourse,dessert,drink);
					   
				  for(x=0;x<arraymenu.size();x++)
				  {
					  menuclient = arraymenu.get(x);
					  
					  if(menucode.equals(menuclient.getCODE()))
					  {
						  found = true;
						  System.out.println("\nThe code(menu) already exists in the database!!\n");
						  break;
					  }
				  }
				  
				  if(!found)
				  {
					  System.out.println("\nThe password does not exist in the database.It will be added now!\n");
					  arraymenu.add(menuclient);
				  }
				  else
				  {
					  for(x=0;x<arraymenu.size();x++)
					   {
						   
						   System.out.println("Password:"  + arraymenu.get(x).getCODE());
						   System.out.println("Maindishes:" + arraymenu.get(x).getMAINDISHES());
						   System.out.println("Desserts:" + arraymenu.get(x).getDESSERTS());
						   System.out.println("Drinks:" + arraymenu.get(x).getDRINKS());
						   System.out.print("\n");
						   
					   } 
				  }
					   
				 
				   
			   }
			   
			   else if(choice == 3) // insert flight
			   {
				   
				   boolean check = false;
				   int foundposition = 0;
				   int z,i,j;
				   int year,day,month;
				   int hour,minute,second;
				   int n = rows;
				   int m = columns;
				   
				   Seat [][] seat = new Seat[n][m];
				   seat = null;
				   
				   String flightcode = password;
				   
                   System.out.println("User insert the departure time:");
				   
                   do
                   {
				      System.out.print("Hours:");
				      hour = input.nextInt();
                   }while(hour < 0 || hour > 24);
				   
                   do
                   {
				      System.out.print("Minutes:");
				      minute = input.nextInt();
                   }while(minute < 0 || minute > 59);
				   
                   do
                   {
				      System.out.print("Seconds:");
				      second = input.nextInt();
                   }while(second < 0 || second > 59);
				   
				   System.out.println("User insert the date of your flight");
				   
				   do
				   {
				      System.out.print("Year:");
				      year = input.nextInt();
				   }while(year < 1000 || year > 9999);
				    
				   do
				   {
				     System.out.print("Month:");
				     month = input.nextInt();
				   }while(month < 1 || month > 12);
				   
				   do
				   {
				     System.out.print("Day:");
				     day = input.nextInt();
				   }while(day < 1 || day > 31);
				   
				   System.out.print("User insert your departure airport:");
				   String departure_airport = enter.readLine();
				   
				   System.out.print("User insert your landing airport:");
				   String landing_airport =  enter.readLine();
				   
				   System.out.print("User insert your airplane model:");
				   String model = enter.readLine();
				   
				   System.out.print("User insert your code for the menu:");
				   String codem = enter.readLine();
				   
				   
				   do
				   {
					   System.out.print("User enter the total seats:");
					   total_seats = input.nextInt();
				   }while(total_seats < 0);
				   
				   do
				   {
					   System.out.print("User enter the reserved seats:");
					   reserved_seats = input.nextInt();
				   }while(reserved_seats < 0);
				   
				   Flight flightclient = new Flight(flightcode,year,Month.of(month),day,hour,minute,second,seat,departure_airport,landing_airport,model,codem,total_seats,reserved_seats);
				   LocalDate date = LocalDate.of(year,Month.of(month),day);
				   
				   for(z=0;z<arrayflight.size();z++)
				   {
					   flightclient = arrayflight.get(z);
					   
					   if(model.equals(flightclient.getAirplane()) && date.equals(flightclient.getdate())) 
					   {
						   System.out.println("\nThe code already exists in the database!!\n");
						   foundposition = z;
						   check = true;
						   break;
					   }
				   }
				   
				   if(!check)
				   {
					   System.out.println("\nThe password does not exist in the database.It will be added now!\n");
					   arrayflight.add(flightclient);
				   }
				   else
				   {
					   for(z=0;z<arrayflight.size();z++)
					   {
						   System.out.println("Password:" + arrayflight.get(z).getCode());
						   System.out.println("Date:" + arrayflight.get(z).getdate());
						   System.out.println("Time:" + arrayflight.get(z).gettime());
						   System.out.println("List:" + arrayflight.get(z).getSeat());
						   System.out.println("Departure_airport:" + arrayflight.get(z).getDeparture_airport());
						   System.out.println("Landing_airport:" + arrayflight.get(z).getLanding_airport());
						   System.out.println("Airplane:" + arrayflight.get(z).getAirplane());
						   System.out.println("Reserved_seats:" + arrayflight.get(z).getReserved_seats());
						   System.out.println("Available_seats:" + arrayflight.get(z).getAvailable_seats());
						   System.out.print("\n");
					   }
					   
				   }
				   
			   }
			   
			   else if(choice == 4) // cancel flight
			   {
				   boolean found = false;
				   
				   System.out.print("User enter the code you want to remove:");
				   String flightcode = enter.readLine();
				   
				   int z,k,l;;
				   
				   
				   for(z=0;z<arrayflight.size();z++)
				   {
					   if(flightcode.equals(arrayflight.get(z).getCode()))
					   {
						   System.out.println("The reservation with the id:" + arrayflight.get(z).getCode() + "\twill be cancelled.");
						   arrayflight.remove(z);
						   found = true;
						   
						   for(int y=0;y<arrayticket.size();y++)
						   {
							   System.out.println("<<Passengers that need to be refunded>>");
							   System.out.println("Fullname:" +arrayticket.get(y).getFullname() + "\tPrice:" + arrayticket.get(y).getPrice());
						   }
						   arrayticket.removeAll(arrayticket);
						   break;
					   }
				   }
				   
				   if(found == false)
				   {
					   System.out.println("This id does not exist in the particular flight!!");
				   }
			   }
			   
			   else if(choice == 5) // insert ticket
			   {
				   boolean place = false;
				   
				   int positionfound = 0;
				   int year,month,dayofmonth;
				   String maindish,desserts,drinks;
				   
				   maindish = null;
				   desserts = null;
				   drinks = null;
				   
				   String passid = password;
				   
				   System.out.print("User insert your ticket publish code for this flight:");
				   ticketcode = enter.readLine();
				   
				   do
				   {
	                   System.out.print("User insert the type of your ticket:");
				       type_ticket = enter.readLine();
				   }while(!type_ticket.equals("Student") && !type_ticket.equals("Normal"));
				   
				   do
				   {
					   System.out.print("User insert the type of your seat:");
					   kind_seat = enter.readLine();
				   }while(!kind_seat.equals("Economy") && !kind_seat.equals("Business"));
				   
				   
				   do
				   {
					   System.out.print("User insert the price of your ticket:");
					   price = input.nextInt();
				   }while(price <= 0);
				   
				   System.out.print("User insert your first and last name:");
				   String fullname = enter.readLine();
				   
				   System.out.println("The publish date of your ticket:");
				   
				   do
				   {
				      System.out.print("Year:");
				      year = input.nextInt();
				   }while(year < 1000 || year > 9999);
				   
				   do
				   {
				      System.out.print("Month:");
				      month = input.nextInt();
				   }while(month < 1 || month > 12);   
				   
				   do
				   {
				      System.out.print("Day:");
				      dayofmonth = input.nextInt();
				   }while(dayofmonth < 1 || dayofmonth > 31);
				   
					
				   if(kind_seat.equals("Business"))
				   {
				       maindish = maincourse;
				       desserts = dessert;
				       drinks = drink;
				   }
				   
				   Ticket ticketclient = new Ticket(passid,ticketcode,year,Month.of(month),dayofmonth,type_ticket,kind_seat,price,fullname,maindish,desserts,drinks);
				   
				   int x;
				   
				   for(x=0;x<arrayticket.size();x++)
					  {
						  ticketclient = arrayticket.get(x);
						  
						  if(kind_seat.equals(ticketclient.getKind_seat()) && (total_seats - reserved_seats > 0))
						  {
							  positionfound = x;
							  place = true;
							  System.out.println("\nThe code(ticket) already exists in the database!!\n");
							  break;
						  }
					  }
					  
					  if(!place)
					  {
						  System.out.println("\nThe password does not exist in the database.It will be added now!\n");
						  arrayticket.add(ticketclient);
					  }
					  else
					  {
						  for(x=0;x<arrayticket.size();x++)
						   {
							   
							   System.out.println("Password:" + arrayticket.get(x).getPassword());
							   System.out.println("Publish_code:" + arrayticket.get(x).getTicketcode());
							   System.out.println("Publish_date:" + arrayticket.get(x).getDate());
							   System.out.println("Ticket(type):" + arrayticket.get(x).getType_ticket());
							   System.out.println("Seat(type):" + arrayticket.get(x).getKind_seat());
							   System.out.println("Price:" + arrayticket.get(x).getPrice() + "�");
							   System.out.println("Fullname:" + arrayticket.get(x).getFullname());
							   System.out.println("Maindish(Business class):" + arrayticket.get(x).getMAINDISHES());
							   System.out.println("Dessert(Business class):" + arrayticket.get(x).getDESSERTS());
							   System.out.println("Drink(Business class):" + arrayticket.get(x).getDRINKS());
							   System.out.print("\n");
							   
						   } 
					  }
				  
				  }
			   
			   else if(choice == 6) // cancel ticket
			   {
                   boolean found = false;
				   
				   System.out.print("User enter the code you want to remove:");
				   String passid = enter.readLine();
				   
				   int x;
				   
				   for(x=0;x<arrayticket.size();x++)
				   {
					   if(passid.equals(arrayticket.get(x).getPassword()))
					   {
						   System.out.println("The reservation with the id:" + arrayticket.get(x).getPassword() + "will be cancelled.");
						   arrayticket.remove(x);
						   found = true;
						   break;
					   }
				   }
				   
				   if(found == false)
				   {
					   System.out.println("This id does not exist in the particular flight!!");
				   }
			   }
			   
			   else if(choice == 7) // Order Menu Items(Only for business seats)
			   {
				   String ticketid,maindish,secondary_dish,liquor;
				   maindish = null;
				   secondary_dish = null;
				   liquor = null;
				   int preference;
				   Seat vip = null;
				   
				   ticketid = ticketcode;
				   
				   if(kind_seat.equals("Business"))
				   {
					   
					   do
					   {
					      System.out.print("\nUser make your choice:");
					      preference = input.nextInt();
					   }while(preference < 1 || preference > 3);
					   
					   if(preference == 1)
					   {
						   maindish = maincourse;
						   secondary_dish = dessert;
						   liquor = drink;
					   }
					   else if(preference == 2)
					   {
						   maindish = maincourse;
					   }
					   else if(preference == 3)
					   {
						   liquor = drink;
					   }
						 
					   vip = new BusinessSeat(password,rows,columns,ticketid,maindish,secondary_dish,liquor);
				   }
				   else if(kind_seat.equals("Economy"))
				   {
					   vip = new EconomySeat(password,rows,columns,ticketid);
				   }
				   
				   if(vip instanceof BusinessSeat)
				   {
					   System.out.printf("\nThe client with id:%s made the particular order(Main plate:%s | Dessert:%s | Drink:%s).\n",password,maindish,secondary_dish,liquor);   
				   }
				   
				   else if(vip instanceof EconomySeat)
				   {
					   System.out.printf("\nThe client with id:%s has booked an economy seat and therefore there will not be a menu available.\n",password);
				   }
			   }
			   
			   else if(choice == 8) // seats capacity for a certain flight
			   {
				   
				    boolean check = false;
				    int gr, co;
				   
					System.out.print("Please enter the flight's ID:");
					String flightcode = enter.readLine();
					
					for(int i=0;i<arrayticket.size();i++) 
					{
						//Begin of if condition
						
						if(flightcode.equals(arrayticket.get(i).getTicketcode())) {
							
							System.out.println("This ID was found!");
							do {
								System.out.print("Please enter the number of your seat's row:");
								gr = input.nextInt();
							}while(gr < 0);
							
							
							do {
								System.out.print("Please enter the number of your seat's column:");
								co = input.nextInt();
							}while(co < 0);
							
							
							String [][] total = new String[rows][columns];
							
							
							// Check for business seats and rows
							for(int x=0;x<=rowsb;x++) {
								
								for(int y=0;y<columns;y++) {
									
									for(int j=0;j<arrayticket.size();j++) {
										
										if(kind_seat.equals("Business") && kind_seat.equals(arrayticket.get(j).getKind_seat())) {
											total[gr][co] = "[[X]]";
										}
										
										if(rowsb == arrayplane.get(j).getBUSINESS()) {
											total[x][y] = "[[]]";	
										}
										
									}
									
								}
								
							}
							
							// check for economic seats
							for(int x=rowsb;x<rows;x++) {
								
								for(int y=0;y<columns;y++) {
									
									for(int j=0;j<arrayticket.size();j++) {
										
										if(kind_seat.equals("Economy") && kind_seat.equals(arrayticket.get(j).getKind_seat())) {
											total[gr][co] = "[X]";
										}
										
										total[x][y] = "[]";
										
									}
									
								}
								
							}
							
							System.out.println();
							for(int x=0;x<rows;x++) {
								
								System.out.println();
								
								for(int y=0;y<columns;y++) {
									System.out.printf("%s\t", total[x][y]);
								}
								
							}
							
							check = true;
						} 
						// End of if condition
						
					}
					
					if(check == false) {
						System.out.println("That id does not exist in the array.");
					}
					
				// End of i
					
				}
				
			   
			}while(choice != 0); // ensures that the user will go to the initial menu if he chooses 1-8

			input.close();
	}
				
		}
	
	 @Override
	   public void actionPerformed(ActionEvent ae) {
	      String userName = userName_text.getText();
	      @SuppressWarnings("deprecation")
		String password = password_text.getText();
	      if (userName.trim().equals("Kkostakis24") && password.trim().equals("Pas$w0rd12")) {
	         message.setText(" Hello " + userName + "");
	      } else {
	         message.setText(" Invalid user.. ");
	      }
	   }
     
	}
