public class BusinessSeat extends Seat
{

	private String maincourse,drinks,desserts;

	public BusinessSeat(String code,int numr,int numc,String ticket,String maincourse,String drinks,String desserts)
	{
		super(code, numr, numc, ticket);
		this.setMaincourse(maincourse);
		this.setDesserts(desserts);
		this.setDrinks(drinks);
	}

	public void setMaincourse(String maincourse) {
		this.maincourse = maincourse;
	}
	
	public String getMaincourse() {
		return this.maincourse;
	}

	public void setDrinks(String drinks) {
		this.drinks = drinks;
	}

	public String getDrinks() {
		return this.drinks;
	}

	public void setDesserts(String desserts) {
		this.desserts = desserts;
	}
	
	public String getDesserts() {
		return this.desserts;
	}
	
}
