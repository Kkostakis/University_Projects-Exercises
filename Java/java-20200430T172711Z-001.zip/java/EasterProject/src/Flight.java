import java.time.LocalDate;          
import java.time.LocalTime;
import java.time.Month;


public class Flight 
{

	private String code;
	private String departure_airport;
	private String landing_airport;
	private String airplane;
	private String menu_code;
	private int available_seats;
	private int reserved_seats;
	private static LocalDate date;
	private static LocalTime time;
	int n,m;
	private Seat [][] seat = new Seat[0][0];
	
	public Flight(String code,int year,Month month,int dayofmonth,int hour,int minute,int second,Seat[][] seat,String departure_airport,String landing_airport,String airplane,String menu_code,int available_seats,int reserved_seats)
	{
		this.setCode(code);
		this.setDeparture_airport(departure_airport);
		this.setLanding_airport(landing_airport);
		this.setAirplane(airplane);
		this.setMenu_code(menu_code);
		this.setAvailable_seats(available_seats);
		this.setReserved_seats(reserved_seats);
		setdate(year,month,dayofmonth);
		settime(hour,minute,second);
		this.setSeat(seat);
	}


	public Seat[][] getSeat() {
		return seat;
	}


	public void setSeat(Seat[][] seat) {
		this.seat = seat;
	}


	public void setCode(String code) 
	{
		this.code = code;
	}

	public void setdate(int year,Month month,int dayofmonth)
	{
		date = LocalDate.of(year, month, dayofmonth);
	}
	
	public static LocalDate getdate()
	{
		return date;
	}
	
	


	public void settime(int hour,int minute,int second)
	{
		time = LocalTime.of(hour,minute,second);
	}
	
	public static LocalTime gettime()
	{
		return time;
	}

	public void setDeparture_airport(String departure_airport) 
	{
		this.departure_airport = departure_airport;
	}

	public void setLanding_airport(String landing_airport) 
	{
		this.landing_airport = landing_airport;
	}

	public void setAirplane(String airplane) 
	{
		this.airplane = airplane;
	}

	public void setMenu_code(String menu_code) 
	{
		this.menu_code = menu_code;
	}

	public void setAvailable_seats(int available_seats) 
	{
		this.available_seats = available_seats;
	}

	public void setReserved_seats(int reserved_seats) 
	{
		this.reserved_seats = reserved_seats;
	}


	public String getCode() 
	{
		return this.code;
	}

	public String getDeparture_airport() 
	{
		return this.departure_airport;
	}

	public String getLanding_airport()
	{
		return this.landing_airport;
	}

	public String getAirplane()
	{
		return this.airplane;
	}

	public String getMenu_code() 
	{
		return this.menu_code;
	}

	public int getAvailable_seats() 
	{
		return this.available_seats;
	}

	public int getReserved_seats() 
	{
		return this.reserved_seats;
	}

	
}
