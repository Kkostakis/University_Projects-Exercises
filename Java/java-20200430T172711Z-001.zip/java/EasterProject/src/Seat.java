public abstract class Seat
{
	
	private String code;
	private int numr;
	private int numc;
	private String ticketid;
	
	public Seat(String code, int numr, int numc, String ticketid) 
	{
		this.setCode(code);
		this.setNumr(numr);
		this.setNumc(numc);
		this.setTicketid(ticketid);
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getNumr() {
		return numr;
	}
	public void setNumr(int numr) {
		this.numr = numr;
	}
	public int getNumc() {
		return numc;
	}
	public void setNumc(int numc) {
		this.numc = numc;
	}
	public String getTicketid() {
		return ticketid;
	}
	public void setTicketid(String ticketid) {
		this.ticketid = ticketid;
	}
	
}