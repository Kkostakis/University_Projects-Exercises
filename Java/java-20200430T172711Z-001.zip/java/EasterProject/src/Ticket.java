import java.time.LocalDate;      
import java.time.Month;

public class Ticket extends Menu{
	
	private String password;
	private String ticketcode;
	private String type_ticket;
	private String kind_seat;
	private int price;
	private String fullname;
	private static LocalDate date;
	
	
	public Ticket(String password,String ticketcode,int year,Month month,int dayofmonth,String type_ticket,String kind_seat,int price,String fullname,String maindish,String dessert,String drink)
	{
		super(null,maindish,dessert,drink);
		this.setPassword(password);
		this.setTicketcode(ticketcode);
		this.setType_ticket(type_ticket);
		this.setKind_seat(kind_seat);
		this.setPrice(price);
		this.setFullname(fullname);
		setDate(year,month,dayofmonth);
		
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setTicketcode(String ticketcode) {
		this.ticketcode = ticketcode;
	}
	
	public String getTicketcode() {
		return this.ticketcode;
	}
	
	public void setType_ticket(String type_ticket) {
		this.type_ticket = type_ticket;
	}
	
	public String getType_ticket() {
		return this.type_ticket;
	}


	public void setKind_seat(String kind_seat) {
		this.kind_seat = kind_seat;
	}
	
	public String getKind_seat() {
		return this.kind_seat;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public int getPrice() {
		return this.price;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	
	public String getFullname() {
		return this.fullname;
	}

	public void setDate(int year,Month month,int dayofmonth)
	{
		date = LocalDate.of(year, month, dayofmonth);
	}
	
	public static LocalDate getDate()
	{
		return date;
	}

}
