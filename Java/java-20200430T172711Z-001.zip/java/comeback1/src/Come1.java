public class Come1 
{
    private String name;
    
    public Come1(String name)
    {
    	this.setName(name);
    }
    
    public void setName(String name)
    {
    	this.name = name;
    }
	
	public String getName()
	{
		return name;
	}
}
