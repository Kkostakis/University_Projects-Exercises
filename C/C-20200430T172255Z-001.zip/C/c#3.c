#include <stdio.h>
#include <stdlib.h>
int main()
{
int x;
int y;
char sel; /*choice of the mathematical process*/
int add; /*addiction*/
int sub; /*subtraction*/
int multi; /*multipication*/
float divi; /*division*/


printf("enter the first interger : ");
scanf("%d",&x);

do
{
printf("enter the second interger : ");
scanf("%d",&y);
}while(y == 0);

printf("enter your choice : ");
scanf(" %c",&sel);

do
{
	
printf("1.addition : '+' \n");
printf("2.subtraction : '-' \n");
printf("3.multiplication : '*' \n");
printf("4.division : '/' \n");
printf("5.exit \n");

if (sel == '1')
{
	add = x + y;
	printf("add is %d\n",add);
}
else if (sel == '2')
{
	sub = x - y;
	printf("sub is %d\n",sub);
}
else if (sel == '3')
{
	multi = x * y;
	printf("multi is %d\n",multi);
}
else if (sel == '4')
{
	divi = (float) x/y;
	printf("divi is %f\n",divi);
}
else 
{
	printf("end the process\n");
}
printf("user give again the first intenger : ");
scanf("%d",&x);
printf("user give again the second intenger : ");
scanf("%d",&y);
printf("user give again your choice : ");
scanf(" %c",&sel);

}while(sel != '5');

return 0;
}
