#include <stdio.h>
#include <stdlib.h>
int main()
{
char gender;
float height;
float weight;
float BMI;
int category;

printf("user please enter your gender(M or F):");
scanf(" %c",&gender);

printf("give the height of the user\n");
scanf("%f",&height);

printf("give the weight of the user\n");
scanf("%f",&weight);
	
if (gender == 'M')
{
  if (height < 1.70)
  {
  	printf("kontos\n");
  	category = 1;
  }
 else if (height < 1.85)
  {
   	printf("kanonikos\n");
   	category = 2;
  }
 else
  {
   	printf("psilos\n");
   	category = 3;
  }
}	
else if (gender == 'F')
{
 if (height < 1.60)
  {
  	printf("konti\n");
    category = 4;
  }
 else if (height < 1.75)
  {
   	 printf("kanoniki\n");
   	 category = 5;
  }
  else
   {
  	 printf("psili\n");
  	 category = 6;
   }	 
}
	
switch(category)
{
  case 1:
  printf("anikei stin katigoria %d\n",category);
  break;
  case 2:
  printf("anikei stin katigoria %d\n",category);
  break;
  case 3:
  printf("anikei stin katigoria %d\n",category);
  break;
  case 4:
  printf("anikei stin katigoria %d\n",category);
  break;
  case 5:
  printf("anikei stin katigoria %d\n",category);
  break;
  case 6:
  printf("anikei stin katigoria %d\n",category);
  break;
}	
	
	
BMI = weight/(height*height);

if (BMI <= 18.5)
{
printf("ellipovaris\n");
}
else if (BMI <= 25)
{
printf("kanoniko varos\n");
	}	
else if (BMI <= 30)
{
printf("ipervaros\n");
	}	
else
{
printf("paxisarkos\n");
}
	
printf("telos programmatos");
return 0;
}

