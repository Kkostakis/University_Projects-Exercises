#include <stdio.h>
#include <stdlib.h>
float average(float sum1,int countp);
float average1(float sum2,int countf);
float average2(float sum3,float sum4,int countp,int countf);
int i;
int k = 0;

int main()
{
	int countp = 0;
    int countf = 0;
    float sum1 = 0;
    float sum2 = 0;
	float avg1,avg2,avg3,avg4;
	float grade[10];
	float success[10];
    float failure[10];
	
	printf("Enter the grade that each student has in C\n");
	for(i = 0;i <= 9;++i)
	{
		do
		{
		    printf("Enter the grade of the student:");
		    scanf("%f",&grade[i]);
		    if(grade[i] == -1)
		    {
		    	printf("stop giving grades\n");
		    	return 0;
			}
	    }while(grade[i] < 0 || grade[i] > 10);
	    
		if(grade[i] >= 5)
		{
			printf("students that passed c\n");
			success[i] = grade[i];
			sum1 = sum1 + success[i];
			countp = countp + 1;
		}
		else if(grade[i] < 5)
		{
			printf("students that did not pass c\n");
			failure[i] = grade[i];
			sum2 = sum2 + failure[i];
			countf = countf + 1;
		}
	} 
	
	avg1 = average(sum1,countp);
	avg2 = average(sum2,countf);
	
	printf("the average of the student's grades(passed)is %.2f\n",avg1);
	printf("the average of the student's grades(failed)is %.2f\n",avg2);
	
    if(countf > countp)
    {
    	float sum3 = 0;
    	float sum4 = 0;
    	for(i = 0;i <= 9;++i)
    	{
    		do
    	    {
    	    	if(grade[i] == 4)
    	    	{
    	    		printf("students that failed\n");
    	    		failure[i] += 1;
    	    		success[k] = failure[i];
    	    		sum3 = sum3 + success[k];
    	    		failure[i] -= grade[i];
    	    		sum4 = sum4 + failure[i];
    	    		countp = countp + 1;
    	    		countf = countf - 1;
				}
		    }while((countp <= countf) && grade[i] == 4);
		}
		
        average2(sum3,sum4,countp,countf);    
	}
   
return 0;
}

float average(float sum1,int countp)
{
	float avg1;
	
	if(countp != 0)
	{
	    avg1 = (float) sum1 / countp;
	}
	
	return avg1;
}

float average1(float sum2,int countf)
{
	float avg2;
	if(countf != 0)
	{
		avg2 = (float) sum2 / countf;
	}
	return avg2;
}
float average2(float sum3,float sum4,int countp,int countf)
{
	float avg3;
	float avg4;
	
	avg3 = (float) sum3 / countp;
	avg4 = (float) sum4 / countf;
	
	printf("the students that passed are:%d\n",countp);
	printf("the students that failed are:%d\n",countf);
}

