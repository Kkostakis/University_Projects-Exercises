#include <stdio.h>
#include <stdlib.h>
int main()
{
	int panel1[4];
	int panel2[4];
	int panel3[4];
	int i;
	
	printf("Please fill the arrays by giving me numbers!!\n");
	printf("Array 1:");
	for(i = 0;i <= 3; ++i)
	{
		scanf("%d",&panel1[i]);
	}
	printf("Array 2:");
	for(i = 0;i <= 3; ++i)
	{
		scanf("%d",&panel2[i]);
	}
	
	printf("Time to add the elements of the two arrays\n");
	printf("Array 1:%d %d %d %d\n",panel1[0],panel1[1],panel1[2],panel1[3]);
	printf("Array 2:%d %d %d %d\n",panel2[0],panel2[1],panel2[2],panel2[3]);
	
	for(i = 0;i <= 3; ++i)
	{
		panel3[i] = panel1[i] + panel2[i];
	}
	
	printf("----------------------------\n");
	printf("Array 3:%d %d %d %d",panel3[0],panel3[1],panel3[2],panel3[3]);
	
	return 0;
}
