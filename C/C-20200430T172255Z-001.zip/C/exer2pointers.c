#include <stdio.h>
#include <stdlib.h>
int main()
{
	int arr[10];
	int *parr;
	parr = &arr[0];
	int i;
	int max;
	
	for(i=0;i<=9;i++)
	{
		printf("User enter multiple integers:");
		scanf("%d",parr+i);
	}
	
	printf("The 3rd number of the array is %d\n",*(parr+2));
	printf("The 8th number of the array is %d\n",*(parr+7));
	
	max = *parr;
	
	for(i=0;i<=9;i++)
	{
		if(max < *(parr+i))
		{
			max = *(parr+i);
		}
	}
	
	printf("The largest number of the array is %d\n",max);
	
	return 0;

}
