#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int compare(int countd, int countw, int countl, char answer[20], char answer2[20]);
int main()
{
	char answer2[20] = R + rand() % S;
	int y = 0;
	char answer[20];
	int number;
	
	scanf(" %s",answer);
	printf("the answer of the user is %s\n",answer);
	printf("the answer of the computer is %c\n",answer2);

    while(y > 6)
    {
    	
    	while(strcmp(answer,"R") != 0 && strcmp(answer,"P") != 0 && strcmp(answer,"S") != 0)
    	{
    		scanf(" %s",answer);
	        printf("the answer of the user is %s\n",answer);
		}
    	printf("the answer of the computer is %c\n",answer2);
    	number = compare(countd, countw, countl, answer[20], answer2[20]);
    	y++;
    }
    
	printf("Your final score\n");
	printf("-------------------------\n");
	printf("Number of wins:%d\n",number);
	printf("Number of losses:%d\n",number); 
	printf("Number of draws:%d\n",number);
	
	return 0;
}

int compare(int countd, int countw, int countl, char answer[20], char answer2)
{
	if(strcmp(answer,answer2) == 0)
	{
		countd = countd + 1;
		return countd;
	}
	else if(strcmp(answer,answer2) > 0)
	{
		countw = countw + 1;
		return countw;
	}
	else
	{
		countl = countl + 1;
		return countl;
	}	
}
