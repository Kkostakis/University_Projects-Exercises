#include <stdio.h>
#include <stdlib.h>
void *passed(int grade[2][3]);
void *failed(int grade[2][3]);
int pass,pass1;
int hold,hold1;
float avg1,avg2;
int sum1,sum2 = 0;
int i,j;

int main()
{
	int grade[2][3];
	int *p, z, *p1, z1;
	for(i=0;i<=1;i++)
	{
		for(j=0;j<=2;j++)
		{
			do
			{
				printf("User enter the grades of the two students:");
				scanf("%d",&z);
				p = &z;
			}while(*p<=0);
			
			grade[i][j] = *p;	
		}
	}
	
	if(grade[i][j] >= 5)
	{
		passed(grade);
	}
	else
	{
		failed(grade);
	}
	
	return 0;
}

void *passed(int grade[2][3])
{
    for(pass=1;pass<3;pass++)
    {
    	for(j=0;j<2;j++)
    	{
    		if(grade[1][j]>grade[1][j+1])
    		{
    			hold = grade[1][j];
    			grade[1][j] = grade[1][j+1];
    			grade[1][j+1] = hold;
			}
		}
	}
	
	for(j=0;j<3;j++)
	{
		printf("The marks of the first student are %d\n",grade[1][j]);
	}
	
	for(pass1=1;pass1<3;pass1++)
    {
    	for(j=0;j<2;j++)
    	{
    		if(grade[2][j]>grade[2][j+1])
    		{
    			hold1 = grade[2][j];
    			grade[2][j] = grade[2][j+1];
    			grade[2][j+1] = hold1;
			}
		}
	}

    for(j=0;j<3;j++)
	{
		printf("The marks of the second student are %d\n",grade[2][j]);
	}
}

void *failed(int grade[2][3])
{
	for(j=0;j<=2;j++)
	{
		sum1 = sum1 + grade[1][j];
		sum2 = sum2 + grade[2][j];
	}
	
	avg1 = sum1/3;
	avg2 = sum2/3;
	
	printf("The average of the first student is %.2f\n",avg1);
	printf("The average of the second student is %.2f\n",avg2);
	
}
