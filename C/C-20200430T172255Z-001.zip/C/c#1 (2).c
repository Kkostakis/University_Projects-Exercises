#include <stdio.h>
int main()
{
	char name[20];
	int year;
	int age;
	int new_age;
	int semester;
	int min;
	
	printf("user enter your name:");
	scanf(" %s",name);
	
	printf("user enter your year:");
	scanf("%d",&year);
	
	printf("user enter your age:");
	scanf("%d",&age);
	
	if(year < 4)
	{
		min = 4 - year;
		new_age = age + min;
		semester = min * 2;
	}
	else if(year == 4)
	{
		min = 1;
		new_age = age + 1;
		semester = 2;
		
	}
	else if(year > 4)
	{
		min = (year - 4) + 1;
		new_age = age + 1;
		semester = min + 1;
	}
	
	printf("onomazomai %s, foitw sto %d etos, kai elpizo na parw to ptixio mou se %d eti, diladi otan tha eimai %d xronwn\n", name, year, min, new_age);
	printf("\t\t\t\t\t\t#DS#ENJOY");
	
}
