#include <stdio.h>
#include <stdlib.h>
int main()
{
	int min, max;
	int sum, average, mult;
	int x, y, z;
	
	scanf("%d%d%d", &x, &y, &z);
	
	sum = x + y + z;
	mult = x * y * z;
	average = (x + y + z) / 3;
	
	max = x;
	min = x;
	if (max < y)
	{
		max = y;
	}
	else if(max < z)
	{
		max = z;
	}
	
	if(min > y)
	{
		min = y;
	}
	else if(min > z)
	{
		min = z;
	}
	
	system("cls");
	printf("Enter three different integers: %d %d %d\n", x, y, z);
	printf("Sum is %d\n",sum);
	printf("Average is %d\n",average);
	printf("Product is %d\n",mult);
	printf("Smallest is %d\n",min);
	printf("Largest is %d\n",max);
	
	return ;
	
}
