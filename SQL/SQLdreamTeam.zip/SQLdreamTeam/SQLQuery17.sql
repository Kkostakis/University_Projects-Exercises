--A)Task-SQL coding part
--1st Question
--SELECT TOP 5 COUNT(Track.AlbumId) as Total, Track.AlbumId, Artist.Name
--FROM InvoiceLine
--INNER JOIN Invoice ON Invoice.InvoiceId=InvoiceLine.InvoiceId
--INNER JOIN Track ON InvoiceLine.TrackId=Track.TrackId
--INNER JOIN Album ON Album.AlbumId=Track.AlbumId
--INNER JOIN Artist ON Artist.ArtistId=Album.AlbumId
--WHERE Invoice.InvoiceDate BETWEEN '2009-01-01 00:00:00.000' and '2009-01-06 00:00:00.000'
--GROUP BY Track.AlbumId, Artist.Name
--ORDER BY Total DESC;


--2nd Question 
--SELECT Top 10 COUNT(Track.Name) as Total , Track.Name 
--FROM PlaylistTrack
--INNER JOIN Track ON PlaylistTrack.TrackId=Track.TrackId
--INNER JOIN Invoice ON Invoice.InvoiceId=Track.TrackId
--WHERE Invoice.InvoiceDate BETWEEN '2009-01-01 00:00:00.000' and '2009-01-06 00:00:00.000'
--GROUP BY Track.Name
--ORDER BY Total DESC;

--3rd Question
--SELECT TOP 1 COUNT(Track.GenreId) as Total, Genre.Name
--FROM PlaylistTrack
--INNER JOIN Track ON PlaylistTrack.TrackId=Track.TrackId
--INNER JOIN Genre ON Track.GenreId=Genre.GenreId
--GROUP BY Track.GenreId, Genre.Name
--ORDER BY Total DESC;


--4th Question
--CREATE VIEW fourthProc AS
--�� 59 ��������� ��� �� ��������� customerid 
--SELECT TOP 59 SUM(Invoice.Total) as Total , Customer.Fax , Customer.Phone , Customer.Email , Customer.CustomerId FROM Invoice
--JOIN Customer ON Invoice.CustomerId=Customer.CustomerId
--GROUP BY Customer.CustomerId , Customer.Fax , Customer.Phone , Customer.Email 
--ORDER BY Total DESC


--5th Question
--CREATE VIEW fifthProc AS
--SELECT Invoice.InvoiceId , Customer.FirstName , Customer.LastName , Employee.FirstName , Employee.LastName FROM Invoice
--INNER JOIN Customer ON Customer.CustomerId=Invoice.InvoiceId
--INNER JOIN Employee ON Employee.EmployeeId=Invoice.CustomerId
--WHERE Invoice.InvoiceDate BETWEEN '2009-01-01 00:00:00.000' and '2009-01-06 00:00:00.000'  

--6th Question
--Create VIEW SixthProc AS
--SELECT Track.Composer  ,  DATEPART(qq, Invoice.InvoiceDate) as QuarterOfYear , Track.Name , COUNT(InvoiceLine.Quantity) as Total ,YEAR(Invoice.InvoiceDate) AS Year From  InvoiceLine 
--Inner Join Invoice ON InvoiceLine.InvoiceId=Invoice.InvoiceId
--Inner Join Track ON InvoiceLine.InvoiceLineId=Track.TrackId
--Where Track.Composer IS NOT Null  AND Track.Composer <>  '' AND Invoice.InvoiceDate Between '2009-01-01' AND '2009-12-31'
--GROUP BY  Track.Name , Track.Composer , DATEPART(qq, Invoice.InvoiceDate) , YEAR(Invoice.InvoiceDate)
--ORDER BY DATEPART(qq, Invoice.InvoiceDate) , Total ,Track.Composer ,Track.Name ASC

--B) Task-Stored Procedure

--IF (EXISTS (SELECT * 
--                 FROM INFORMATION_SCHEMA.TABLES 
--                 WHERE TABLE_SCHEMA = 'dbo' 
--                 AND  TABLE_NAME = 'InvoiceStatistics'))
--BEGIN
--DELETE FROM InvoiceStatistics;
--INSERT INTO InvoiceStatistics (Invoice.GenreId, InvoiceLine.TrackId, )
--SELECT Invoice.GenreId, InvoiceLine.TrackId, 
--FROM Invoice, InvoiceLine
--END

--IF NOT EXISTS (SELECT * 
--                FROM INFORMATION_SCHEMA.TABLES 
--                WHERE TABLE_SCHEMA = 'dbo' 
--                AND  TABLE_NAME = 'InvoiceStatistics'))
--BEGIN
--CREATE TABLE InvoiceStatistics (
--Genreid INT,
--Trackid INT,
--TotalTrackCharge FLOAT,
--TimeCreated DATETIME
--);
--END
