--A) Task
--user input orizoume poia einai top album se pwliseis kai se poio diastima
--1st Question
--CREATE PROCEDURE FirstProc AS
--SELECT TOP 5 COUNT(Track.AlbumId) as Total, Track.AlbumId, Artist.Name
--FROM InvoiceLine
--INNER JOIN Invoice ON Invoice.InvoiceId=InvoiceLine.InvoiceId
--INNER JOIN Track ON InvoiceLine.TrackId=Track.TrackId
--INNER JOIN Album ON Album.AlbumId=Track.AlbumId
--INNER JOIN Artist ON Artist.ArtistId=Album.AlbumId
--WHERE Invoice.InvoiceDate BETWEEN '2009-01-01 00:00:00.000' and '2009-01-06 00:00:00.000'
--GROUP BY Track.AlbumId, Artist.Name
--ORDER BY Total DESC;

--OXI USER INPUT
--2nd Question 
--CREATE VIEW SecondProc AS
--SELECT Top 10 COUNT(Track.Name) as Total , Track.Name 
--FROM PlaylistTrack
--INNER JOIN Track ON PlaylistTrack.TrackId=Track.TrackId
--INNER JOIN Invoice ON Invoice.InvoiceId=Track.TrackId
--WHERE Invoice.InvoiceDate BETWEEN '2009-01-01 00:00:00.000' and '2009-01-06 00:00:00.000'
--GROUP BY Track.Name
--ORDER BY Total DESC;

--OXI USER INPUT
--3rd Question
--CREATE VIEW ThirdProc AS
--SELECT TOP 1 COUNT(Track.GenreId) as Total, Genre.Name
--FROM PlaylistTrack
--INNER JOIN Track ON PlaylistTrack.TrackId=Track.TrackId
--INNER JOIN Genre ON Track.GenreId=Genre.GenreId
--GROUP BY Track.GenreId, Genre.Name
--ORDER BY Total DESC;

-- user input gia to xroniko diastima paraggeliwn
--4th Question
--CREATE VIEW fourthProc AS
--�� 59 ��������� ��� �� ��������� customerid 
--SELECT TOP 59 SUM(Invoice.Total) as Total , Customer.Fax , Customer.Phone , Customer.Email , Customer.CustomerId FROM Invoice
--JOIN Customer ON Invoice.CustomerId=Customer.CustomerId
--GROUP BY Customer.CustomerId , Customer.Fax , Customer.Phone , Customer.Email 
--ORDER BY Total DESC

-- o xristis prepei na dinei to xroniko diastima paraggeliwn dld imerominia apo-ews, epilogi pelatwn apo diskografia kai ipallilos poi sxetizetai me tin paraggelia.
--Ousiastika kanw ton ipallilo user-input kai o xristis apla na dinei tin imerominia
--5th Question
--CREATE VIEW fifthProc AS
--SELECT Invoice.InvoiceId , Customer.FirstName , Customer.LastName , Employee.FirstName , Employee.LastName FROM Invoice
--INNER JOIN Customer ON Customer.CustomerId=Invoice.InvoiceId
--INNER JOIN Employee ON Employee.EmployeeId=Invoice.CustomerId
--WHERE Invoice.InvoiceDate BETWEEN '2009-01-01 00:00:00.000' and '2009-01-06 00:00:00.000'



--SELECT * FROM Track
--6th Question
--CREATE VIEW SixthProc AS
--SELECT Track.Composer  ,  DATEPART(qq, Invoice.InvoiceDate) AS DatePartInt , Track.Name , COUNT(InvoiceLine.Quantity) AS Total, YEAR(Invoice.InvoiceDate) AS Year FROM  InvoiceLine
--INNER JOIN Invoice ON InvoiceLine.InvoiceId=Invoice.InvoiceId
--INNER JOIN Track ON InvoiceLine.InvoiceLineId=Track.TrackId AND Invoice.InvoiceDate BETWEEN  '2009-01-01' AND '2009-01-31'
--WHERE Track.Composer is NOT NULL AND Track.Composer <> '' --Edw tha mpei me user input to etos paraggelias tou tragoudiou
--GROUP BY  Track.Name , Track.Composer , DATEPART(qq, Invoice.InvoiceDate), YEAR(Invoice.InvoiceDate)
--ORDER BY DatePartInt, Total, Track.Composer, Track.Name ASC


--B) Task-Stored Procedure

CREATE PROCEDURE StatisticProc AS
IF (EXISTS (SELECT * 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_SCHEMA = 'dbo' 
                AND  TABLE_NAME = 'InvoiceStatistics'))
BEGIN
DELETE FROM InvoiceStatistics;

INSERT INTO InvoiceStatistics (InvoiceStatistics.Genreid, InvoiceStatistics.Trackid, InvoiceStatistics.TotalTrackCharge, InvoiceStatistics.TimeCreated)
SELECT Genre.GenreId, InvoiceLine.TrackId, (InvoiceLine.UnitPrice * InvoiceLine.Quantity) as total, Invoice.InvoiceDate
FROM Invoice, InvoiceLine, Genre
END

IF NOT EXISTS (SELECT * 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_SCHEMA = 'dbo' 
                AND  TABLE_NAME = 'InvoiceStatistics')
BEGIN
CREATE TABLE InvoiceStatistics (
Genreid INT,
Trackid INT,
TotalTrackCharge FLOAT,
TimeCreated DATETIME
);

INSERT INTO InvoiceStatistics (InvoiceStatistics.Genreid, InvoiceStatistics.Trackid, InvoiceStatistics.TotalTrackCharge, InvoiceStatistics.TimeCreated)
SELECT Genre.GenreId, InvoiceLine.TrackId, (InvoiceLine.UnitPrice * InvoiceLine.Quantity) as total, Invoice.InvoiceDate
FROM Invoice, InvoiceLine, Genre
END

